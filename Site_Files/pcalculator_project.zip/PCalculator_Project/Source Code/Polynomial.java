
/**
 * Class representation of a polynomial
 *
 * @author Spencer Lee
 * @version 1.0
 */
 
import java.util.*;

public class Polynomial {

    /** Array list to store each monomial */
    private ArrayList<Monomial> terms = new ArrayList<Monomial>();
    /** Flag if polynomial is sorted */
    private boolean sorted = false;
    /** Flag if polynomial is simiplified */
    private boolean simplified = false;
    
    //methods 
    
    /** Getter to check if the polynomial is simplified
     * 
     * @return true if the polynomial is simplified
     */
    public boolean isSimplified() {
        return simplified;
    }
    
    /** Getter for a monomial/term
     * 
     * @param index the index at which to get the term
     * @return the monomial at the index
     */
    public Monomial getTerm(int index) {
        return terms.get(index);
    }
    
    /** Getter for the size of the polynomial
     * 
     * @return the number of terms in the polynomial
     */
    public int getSize() {
        return terms.size();
    }
    
    /** Adds a monomial to the polynomial
     * 
     * @return true/false if it was successfully added or not
     */
    public boolean insertTerm(Monomial term) {
        return terms.add(term);
    }
    
    /** Sort the terms by exponent
     * 
     */
    public void sortTerms() {
        Collections.sort(terms);
        // Poly is sorted
        sorted = true;
    }
    
    /** Copies the polynomial
     * 
     * @return the copied polynomial
     */
    public Polynomial clone() {
        int i;
        Polynomial clonedPoly = new Polynomial();
        
        for (i = 0; i < getSize(); i++) {
            clonedPoly.insertTerm(getTerm(i).clone());
        }
        
        return clonedPoly;
    }
    
    /** Simplifies (and sorts) the polynomial
     * 
     */
    public void simplify() {
        // If the polynomial isn't sorted yet, sort it now
        if (!sorted)
            sortTerms();
    
        int i;
        ArrayList<Monomial> simplifiedTerms = new ArrayList<Monomial>();
        Monomial currTerm;
        Monomial nextTerm = null;
        Monomial termSum = null;
        
        if (getSize() > 0)
            termSum = getTerm(0);
        
        // For each term...
        for (i = 0; i < getSize(); i++) {
            currTerm = getTerm(i);
            
            // If we reach end of polynomial, put in the final simplified term
            if (i == getSize()-1 && termSum.getCoeff() != 0)
                simplifiedTerms.add(termSum);
        
            // If the coefficient is 0, ignore it
            else if (termSum.getCoeff() != 0) {
                nextTerm = getTerm(i+1);
                // Can only add terms if their exponents are equal
                if ( currTerm.getExpt() == nextTerm.getExpt() ) {
                    termSum = ( termSum.plus(nextTerm) );
                }
                    
                // If exponents are not equal, there's nothing more to simplify
                // throw it into the list as long as it didn't zero out
                else if (termSum.getCoeff() == 0) {
                    termSum = nextTerm;
                }
                else {
                    simplifiedTerms.add(termSum);
                    termSum = nextTerm;
                }
            }
        }
        
        terms = simplifiedTerms;
        
        // Poly is simplified
        simplified = true;
    }
    
    /** Adds two polynomials together
     * 
     * @return a polynomial, the result of adding b to this
     * @param b another polynomial to be added
     */
    public Polynomial plus(Polynomial b) {
        int i = 0, j = 0;
        Polynomial finalPoly = new Polynomial();
        Monomial termA, termB, result;
        
        if (!simplified)
            simplify();
        if (!b.isSimplified())
            b.simplify();
        
        // if either operand is 0, just return the non-zero polynomial
        if (getSize() == 0)
            return b.clone();
        else if (b.getSize() == 0)
            return clone();
        
        // While there are any terms left in the polynomials...
        while (i < getSize() || j < b.getSize()) {
            
            // Case 1: we are out of terms, throw in rest of b's terms
            if ( i >= getSize() ) {
                termB = b.getTerm(j);
                finalPoly.insertTerm(termB);
                j++;
            }
                
            // Case 2: b is out of terms, throw in the rest of our terms
            else if ( j >= b.getSize() ) {
                termA = getTerm(i);
                finalPoly.insertTerm(termA);
                i++;
            }
            else {
                termA = getTerm(i);
                termB = b.getTerm(j);
                
                // Case 3: b's exponent is bigger than our exponent,
                //         throw in b's term
                if ( termB.getExpt() > termA.getExpt() ) {
                    finalPoly.insertTerm(termB);
                    j++;
                }
                // Case 4: our exponent is bigger than b's exponent,
                //         throw in our term
                else if ( termA.getExpt() > termB.getExpt() ) {
                    finalPoly.insertTerm(termA);
                    i++;
                }
                // Case 5: exponents are equal, add terms together
                else {
                    result = termA.plus(termB);
                    if (result != null && result.getCoeff() != 0)
                        finalPoly.insertTerm(result);
                    
                    i++;
                    j++;
                }
            }
        }
        
        return finalPoly;
    }
    
    /** Subtracts two polynomials
     * 
     * @return a polynomial, the result of subtracting b from this
     * @param b another polynomial to be subtracted
     */
    public Polynomial minus(Polynomial b) {
        int i = 0, j = 0;
        Polynomial finalPoly = new Polynomial();
        Monomial termA, termB, result;
        
        if (!simplified)
            simplify();
        if (!b.isSimplified())
            b.simplify();
            
        // multiply b by -1
        b = b.times(new Monomial(-1, 'x', 0));
        
        // now add
        return this.plus(b);
    }
    
    
    /** Multiplies a polynomial by a monomial
     * 
     * @return a polynomial, the result of multiplying b with this
     * @param bTerm another monomial to be multiplied
     */
    public Polynomial times(Monomial bTerm) {
        int i, j;
        Polynomial finalPoly = new Polynomial();
        
        for (i = 0; i < getSize(); i++)
            finalPoly.insertTerm( getTerm(i).times(bTerm) );
        
        return finalPoly;
    }
    
    /** Multiplies two polynomials together
     * 
     * @return a polynomial, the result of multiplying b with this
     * @param b another polynomial to be multiplied
     */
    public Polynomial times(Polynomial b) {
        int i, j;
        Polynomial finalPoly = new Polynomial();
        Monomial termA, termB;
        
        for (i = 0; i < getSize(); i++) {
            termA = getTerm(i);
            
            for (j = 0; j < b.getSize(); j++) {
                termB = b.getTerm(j);
                finalPoly.insertTerm( termA.times(termB) );
            }
        }
        
        finalPoly.simplify();
        
        return finalPoly;
    }
    
    /** Divides two polynomials
     * 
     * @return a polynomial, the result of dividing this by b
     * @param b another polynomial divide by
     */
    public Polynomial divideBy(Polynomial b) {
        Polynomial finalPoly = new Polynomial();
        Polynomial tempPoly = this;
        Monomial firstTerm = null;
        
        if (!simplified)
            simplify();
        if (!b.isSimplified())
            b.simplify();
        
        if (b.getSize() == 0) {
            System.out.println("Hey whoa! You tryna make some black holes " +
                               "or somethin? (division by 0)");
            return null;
        }
        
        else if (getSize() != 0) {
            // Initially set firstTerm
            firstTerm = getTerm(0);
            
            //long division
            while (tempPoly.getSize() > 0) {
            
                // Is there a remainder?
                if (firstTerm.getExpt() < 0) {
                    System.out.println("No can do! Division yielded " +
                                       "non-zero remainder.");
                    return null;
                }
                
                // update firstTerm
                firstTerm = tempPoly.getTerm(0);
                
                // divide first mono by b's first mono
                firstTerm = firstTerm.divideBy( b.getTerm(0) );
                finalPoly.insertTerm(firstTerm);
                
                // new calculated poly - (b * first mono)
                tempPoly = tempPoly.minus( b.times(firstTerm) );
            }
        }
        
        // Check for remainder after division is done
        if (firstTerm != null && firstTerm.getExpt() < 0) {
            System.out.println("No can do! Division yielded " +
                               "non-zero remainder.");
            return null;
        }
        
        return finalPoly;
    }
    
    /** Overrides the toString method
     * 
     * @return a string representation of the polynomial
     */
    public String toString() {
        int i;
        double coefficient;
        String coefficientStr;
        String decimals;
        int coeLen;
        int exponent;
        char variable;
        Monomial term;
        String pStr = "";
        
        // if there are no terms, the polynomial is 0
        if (getSize() == 0)
            return "0";
        
        for (i = 0; i < getSize(); i++) {
            term = getTerm(i);
            coefficient = term.getCoeff();
            variable = term.getVar();
            exponent = term.getExpt();
            
            
            // print plus and minus signs for the terms
            if (coefficient > 0 && i > 0)
                pStr += " + ";
            else if (coefficient < 0 && i > 0) {
                pStr += " - ";
                // prevent two negative signs from being shown
                coefficient *= -1;
            }
            else if (coefficient < 0 && i == 0) {
                pStr += "-";
                // prevent two negative signs from being shown
                coefficient *= -1;
            }
            
            // Only 2 decimal places
            coefficientStr = String.format("%.2f", coefficient);
            coeLen = coefficientStr.length();
            decimals = coefficientStr.substring(coefficientStr.length()-2);
            
            // Don't print decimal if no decimals
            if (decimals.compareTo("00") == 0)
                coefficientStr = coefficientStr.substring(0, coeLen-3);
            // Don't print trailing 0
            else if (decimals.charAt(1) == '0')
                coefficientStr = coefficientStr.substring(0, coeLen-1);
            
            // print coefficients of 1 if there's no x
            if ((coefficient == 1 || coefficient == -1) && exponent == 0)
                pStr += coefficientStr;
            
            // don't print coefficients of 1 if there's x
            else if (coefficient != 1 && coefficient != -1 && exponent >= 0)
                pStr += coefficientStr;
            
            // don't print x if expt is 0
            if (exponent > 0)
                pStr += variable;
            
            // don't print exponent if it's 0 or 1
            if (exponent > 1)
                pStr += "^" + exponent;
        }
        
        return pStr;
    }
}

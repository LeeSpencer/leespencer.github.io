/**
 * Polynomial Calculator
 *
 * @author Spencer Lee
 * @version 1.0
 */
import java.util.*;
import java.io.*; 

public class PCalculator {
    /** hashmap of saved polynomials */
    Map<Character, Polynomial> polyMap = new HashMap<Character, Polynomial>();
    
    
    //methods
    
    /** Prints a menu and prompts user for mode
     * 
     */
    public void promptMenu() {
        int option = -1;
        Scanner scanner = new Scanner(System.in);
        boolean changingMode = false;
        
        System.out.println();
        System.out.println("     Pick your poison");
        System.out.println("---------------------------");
        System.out.println("1) Interactive Mode");
        System.out.println("2) File Mode");
        System.out.println("3) Fancy Mode");
        System.out.println("4) Exit Program");
        System.out.println();
        
        try {
            System.out.print("Option: ");
            option = Integer.parseInt(scanner.nextLine());
            
            if (option == 1)
                changingMode = interactiveMode();
                
            else if (option == 2)
                changingMode = fileMode();
                
            else if (option == 3)
                new FancyCalc(this);
                
            else if (option == 4)
                return;
                
            else {
                System.out.println ("Please enter a number from 1 to 4.");
                promptMenu();
            }
            
            if (changingMode)
                promptMenu();
        }
        catch (NumberFormatException e) {
            System.out.println("Please enter a number from 1 to 4.");
            promptMenu();
        }
    }
    
    /** Prompts for filepath and evaluates file contents
     * 
     * @return true if user wants to change mode, false if user wants to exit
     */
    private boolean fileMode() {
        Scanner scanner = new Scanner(System.in);
        String input;
        
        // Prompt
        System.out.println("\nType exit to exit the program.");
        System.out.println("Type changemode to switch modes.");
        System.out.print("Path to file: ");
        
        // Initial input
        input = scanner.nextLine().toLowerCase();
        
        // While user doesn't want to exit or change modes
        while (input.compareTo("exit") != 0 &&
               input.compareTo("changemode") != 0) {
               
            // buffered reading
            try {
                BufferedReader br = new BufferedReader(new FileReader(input));

                // read the first line, check if it is null, if not, keep reading
                for (String line = br.readLine(); line !=null; line = br.readLine()) {
                    // Evaluate the line
                    System.out.println(parseExpression(line, false));
                }

                // close the reader
                br.close();
            }
            catch (IOException e) {
                System.err.println(e);
            }
            
            // Get next input
            System.out.println("\nType exit to exit the program.");
            System.out.println("Type changemode to switch modes.");
            System.out.print("Path to file: ");
            input = scanner.nextLine().toLowerCase();
        }
        
        // input is either changemode or exit at this point
        return (input.compareTo("changemode") == 0);
    }
    
    /** Prompts for individual expressions and evaluates them
     * 
     * @return true if user wants to change mode, false if user wants to exit
     */
    private boolean interactiveMode() {
        Scanner scanner = new Scanner(System.in);
        String input;
        
        // Prompt
        System.out.println("Example expression: a = 3x^2 + 3x");
        System.out.println("Example expression: b = 5x");
        System.out.println("Example expression: (a + b)*(3x - 9)");
        System.out.println("\nType exit to exit the program.");
        System.out.println("Type changemode to switch modes.");
        System.out.print("Expression: ");
            
        // Initial input
        input = scanner.nextLine().toLowerCase();
        
        // While user doesn't want to exit or change mode
        while (input.compareTo("exit") != 0 &&
               input.compareTo("changemode") != 0) {
           
            // Evaulate expression
            System.out.println(parseExpression(input, false));
            
            // Get next input
            System.out.print("\nExpression: ");
            input = scanner.nextLine().toLowerCase();
        }
        
        // input is either changemode or exit at this point
        return (input.compareTo("changemode") == 0);
    }
    
    /** Evaluates an expression in string form
     * 
     * @param input the expression to parse
     * @return an output message string
     */
    public String parseExpression(String input, boolean isFancyMode) {
        int eqIdx;
        char varToSave;
        String leftHand, rightHand;
        Polynomial result;
        String msg = "";
        
        if (!isFancyMode) {
            System.out.println("Input : " + input);
            System.out.println("Output: ");
        }
        
        // Did user type "=" anywhere?
        eqIdx = input.indexOf("=");
        
        // No - output the result but don't save it
        if (eqIdx == -1) {
            result = expressionToPoly(input);
            
            if (result != null)
                msg = result.toString();
        }
        
        // Yes - but only "="
        else if (eqIdx == input.length()-1) {
            msg = "I don't recognize that one!";
        }
        
        // Yes - output and save the result if valid
        else {
            // Get the lefthand and righthand sides of the equation
            leftHand = input.substring(0, eqIdx);
            rightHand = input.substring(eqIdx+1);
            
            // Is the lefthand side valid?...
            
            // Trim whitespace
            leftHand = leftHand.trim();
            
            // There must be exactly one alphabetical character left
            if (leftHand.length() > 1)
                msg = "Left-hand side of the equation is invalid.";
                
            else {
                // Get the polynomial variable
                varToSave = leftHand.charAt(0);
                varToSave = Character.toLowerCase(varToSave);
                
                // Make sure it's alphabetic and not x
                if (Character.isAlphabetic(varToSave) && varToSave != 'x') {
                    result = expressionToPoly(rightHand);
                    
                    // Save/output it if valid
                    if (result != null) {
                        polyMap.put(varToSave, result);
                        msg = varToSave + " = " + result;
                    }
                }
                
                // Error if x
                else if (varToSave == 'x')
                    msg = "x cannot be used as a polynomial variable.";
                
                // Error if not alphabetic
                else
                    msg = "Please use a letter from A - Z " +
                          "(not x) on the left-hand side.";
            }
        }
        
        return '\n' + msg + '\n';
    }
    
    /** Polynomial-izes a string expression
     * 
     * @return a polynomial
     */
    private Polynomial expressionToPoly(String expression) {
        ArrayList<AToken> infixTokens, postfixTokens;
        Polynomial result;
        
        // Get tokens in infix
        infixTokens = tokenize(expression);
        // Convert infix to postfix
        postfixTokens = infixToPostfix(infixTokens);
        // Get the resulting polynomial
        result = postfixToPoly(postfixTokens);
        
        
        // Was the expression determined as invalid at any point?
        if (infixTokens == null || postfixTokens == null || result == null)
            return null;
        
        else return result;
    }
    
    /** Converts a list of tokens in infix to postfix
     * 
     * @param infixExp a list of tokens in infix
     * @return a list of tokens in postfix
     */
    private ArrayList<AToken> infixToPostfix(ArrayList<AToken> infixExp) {
        ArrayList<AToken> postfixExp = new ArrayList<AToken>();
        ArrayDeque<AToken> operatorStack = new ArrayDeque<AToken>();
        AToken operator;
        
        // If infixExp is invalid
        if (infixExp == null) {
            System.out.println("I don't recognize that one!");
            return null;
        }
        
        // For each token...
        for (AToken token : infixExp) {
            // If operand, append to output
            if (token.isOperand())
                postfixExp.add(token);
            
            // If '(', add to stack
            else if (token.isOpenParen())
                operatorStack.addFirst(token);
            
            // if ')', remove operators from stack until '('
            else if (token.isCloseParen()) {
            
                while (!operatorStack.isEmpty() && !operatorStack.peekFirst().isOpenParen()) {
                    postfixExp.add( operatorStack.removeFirst() );
                }
                
                // If it's empty, we didn't reach that '('
                if (operatorStack.isEmpty()) {
                    System.out.println("Uh-oh! Mismatched right parentheses.");
                    return null;
                }
                
                // Take off the '('
                operatorStack.removeFirst();
            }
            
            // If operator, append to output operators with higher priority until '('
            else if (token.isOperator()) {
                while (!operatorStack.isEmpty() &&
                        !operatorStack.peekFirst().isOpenParen() &&
                        operatorStack.peekFirst().getPriority() >= token.getPriority()) {
                        
                        postfixExp.add( operatorStack.remove() ); 
                }

                // add the current operator to the stack
                operatorStack.addFirst(token); 
            }
        }
            
        // have processed entire expression, time to empty out the stack
        while (!operatorStack.isEmpty()){
            operator = operatorStack.removeFirst(); 

            // there shouldn't be a left parenthesis on the stack
            // this means a corresponding right one was never found, error
            if (operator.isOpenParen()) {
                System.out.println("Uh-oh! Mismatched left paranthesis.");
                return null;
            }
              
            // add tokens to output
            postfixExp.add(operator);
       }
        
        return postfixExp;
    }
    
    /** Evaluates a list of tokens in postfix
     * 
     * @param postfixExp a list of tokens in postfix
     * @return the resulting polynomial
     */
    private Polynomial postfixToPoly(ArrayList<AToken> postfixExp) {
        ArrayDeque<AToken> operandStack = new ArrayDeque<AToken>();
        AToken operand1, operand2, result;
        
        // If the postfixExp is invalid, return null
        if (postfixExp == null)
            return null;
        
        // For each token...
        for (AToken token : postfixExp) {

            // If operand, add it to the stack
            if (token.isOperand())
                operandStack.addFirst(token);

            else if (token.isOperator()){
                // remove both operands from the top of the stack
                operand2 = operandStack.removeFirst();
                operand1 = operandStack.removeFirst();
                 
                // compute the result of the operation on the operands
                result = token.operate(operand1, operand2);

                // add the result to the top of the stack
                operandStack.addFirst(result); 
            }
        }
        
        // finished processing the expression now, take final result off stack
        result = operandStack.removeFirst();
        
        return result.getPoly();
    }
    
    /** A simple helper function that checks if a character is an operator
     * 
     * @param c a character
     * @return true if it is an operator
     */
    private boolean isOperator(char c) {
        return (c == '+' || c == '-' || c == '*' || c == '/' || c == ')');
    }
    
    /** Converts a string expression into a list of tokens in infix
     * 
     * @param expression a string representation of the expression
     * @return a list of tokens in infix
     */
    private ArrayList<AToken> tokenize (String expression) {
        // For the loop
        int i = 0;
        int len = expression.length();
        
        // variables to save monomial info as it's read
        String newCoefficient = "0";
        String newExponent = "0";
        Monomial newTerm = null;
        Polynomial newPoly = new Polynomial();
        char lastOp = '?';
        
        // Resulting list of tokens
        ArrayList<AToken> tokenList = new ArrayList<AToken>();
        
        // Set initial state
        State curState = State.WTERM;
        
        // While not in error state and there are characters left
        while (curState != State.ERR && i < len) {
            char c = expression.charAt(i);
            c = Character.toLowerCase(c);
            i++;
            
            switch (curState) {
            
                ////////////////////////////////////////////////////////////
                // waiting for an operator after a polynomial was given...
                ////////////////////////////////////////////////////////////
                case WPLYOP:
                    // if we get an operator, save it and wait for a new term
                    if (isOperator(c)) {
                        lastOp = c;
                        
                        // if a closed paren
                        if (c != ')')
                            curState = State.WTERM;
                            
                            
                        tokenList.add( new Operator(c) );
                    }
                    // anything else is error (ignore whitespace)
                    else if (c != ' ')
                        curState = State.ERR;
                    break;
                    
                    
                ////////////////////////////////////////////////////////////
                // waiting for the start of a term (num/x/a-z)...
                ////////////////////////////////////////////////////////////
                case WTERM:
                    // if a number, save it and wait for an x
                    if (Character.isDigit(c)) {
                        curState = State.WVAR;
                        newCoefficient += c;
                    }
                    // if a minus sign, insert 0 - token (no double negs tho)
                    else if (c == '-' && lastOp != '-') {
                            Monomial zero = new Monomial (0, 'x', 0);
                            Polynomial zeroPoly = new Polynomial();
                            zeroPoly.insertTerm(zero);
                            
                            tokenList.add( new Operand(zeroPoly) );
                            tokenList.add( new Operator(c) );
                            
                            lastOp = '-';
                    }
                    
                    // if x, wait for either an operator or an exponent
                    else if (c == 'x') {
                        curState = State.WEXPO;
                        // no coefficient given so assume it as 1
                        newCoefficient = "1";
                    }
                    
                    // if an alphabetic char (not x)
                    else if (Character.isAlphabetic(c)) {
                        // if there is a pending polynomial, save it now
                        if (newPoly.getSize() > 0) {
                            tokenList.add( new Operand(newPoly) );
                            // reset newPoly
                            newPoly = new Polynomial();
                        }
                        // if the character we read is a saved polynomial
                        if (polyMap.containsKey(c)) {
                            curState = State.WPLYOP; 
                            tokenList.add( new Operand( polyMap.get(c) ) );
                        }
                        // otherwise, error
                        else {
                            System.out.println(c + ": no such polynomial exists");
                            curState = State.ERR;
                        }
                        
                    }
                    // if open paren, save and keep state
                    else if (c == '(')
                        tokenList.add( new Operator(c) );
                    // anything else is error (ignore whitespace and open parens)
                    else if (c != ' ')
                        curState = State.ERR;
                    break;
                
                
                ////////////////////////////////////////////////////////////
                // waiting for a variable...
                ////////////////////////////////////////////////////////////
                case WVAR:
                    // if x is given, wait for operator or exponent
                    if (c == 'x')
                        curState = State.WEXPO;
                    
                    // if another number is given, keep state and save it
                    else if (Character.isDigit(c))
                        newCoefficient += c;
                    
                    // if we see a decimal, wait for a number
                    else if (c == '.' && !newCoefficient.contains(".")) {
                        curState = State.WDNUM;
                        newCoefficient += c;
                    }
                    
                    // if an operator is given, save the monomial and restart
                    else if (isOperator(c)) {
                        lastOp = c;
                        
                        // if a closed paren
                        if (c == ')')
                            curState = State.WONLYOP;
                        else
                            curState = State.WTERM;
                            
                            
                        // make the monomial and insert into our polynomial
                        newTerm = new Monomial(Double.parseDouble(newCoefficient),
                                               'x',
                                               Integer.parseInt(newExponent));
                        
                        newPoly.insertTerm(newTerm);
                        
                        // save the tokens
                        tokenList.add( new Operand(newPoly) );
                        tokenList.add( new Operator(c) );
                        
                        // Reset variables
                        newPoly = new Polynomial();
                        newExponent = "0";
                        newCoefficient = "0";
                        
                    }
                    
                    // anything else is error (ignore whitespace and closed parens)
                    else if (c != ' ')
                        curState = State.ERR;
                    
                    break;
                
                
                
                ////////////////////////////////////////////////////////////
                // waiting for a number after a decimal...
                ////////////////////////////////////////////////////////////
                case WDNUM:
                    // if a number, save it and rest easy now
                    if (Character.isDigit(c)) {
                        newCoefficient += c;
                        curState = State.WVAR;
                    }
                    // anything else is error (ignore whitespace)
                    else if (c != ' ')
                        curState = State.ERR;
                    
                    break;
                
                
                
                
                ////////////////////////////////////////////////////////////
                // waiting for exponent...
                ////////////////////////////////////////////////////////////
                case WEXPO:
                    // if given the carat, wait for the actual degree
                    if (c == '^')
                        curState = State.WDEGR;
                        
                    // if given operator, save the monomial and restart
                    else if (isOperator(c)) {
                        lastOp = c;
                        
                        // if a closed paren
                        if (c == ')')
                            curState = State.WONLYOP;
                        else
                            curState = State.WTERM;
                        
                        //if we have x but no exponent was given,
                        // we can assume it as 1
                        if (newExponent == "0")
                            newExponent = "1";
                        
                        // make the monomial and insert into our polynomial
                        newTerm = new Monomial(Double.parseDouble(newCoefficient),
                                               'x',
                                               Integer.parseInt(newExponent));
                        
                        newPoly.insertTerm(newTerm);
                        
                        // save the tokens
                        tokenList.add( new Operand(newPoly) );
                        tokenList.add( new Operator(c) );
                        
                        // Reset variables
                        newPoly = new Polynomial();
                        newExponent = "0";
                        newCoefficient = "0";
                    }
                    
                    // anything else is error (ignore whitespace)
                    else if (c != ' ')
                        curState = State.ERR;
                    
                    break;
                
                
                
                ////////////////////////////////////////////////////////////
                // waiting for a degree...
                ////////////////////////////////////////////////////////////
                case WDEGR:
                    // if given the degree number, wait for an operator
                    if (Character.isDigit(c)) {
                        curState = State.WOPER;
                        newExponent += c;
                    }
                    // anything else is error (ignore whitespace)
                    else if (c != ' ')
                        curState = State.ERR;
                    
                    break;
                
                
                
                
                ////////////////////////////////////////////////////////////
                // waiting for an operator...
                ////////////////////////////////////////////////////////////
                case WOPER:
                    // if given operator, save monomial and restart
                    if (isOperator(c)) {
                        lastOp = c;
                        
                        // if a closed paren
                        if (c == ')')
                            curState = State.WONLYOP;
                        else
                            curState = State.WTERM;
                        
                        // make the monomial and insert into our polynomial
                        newTerm = new Monomial(Double.parseDouble(newCoefficient),
                                               'x',
                                               Integer.parseInt(newExponent));
                        
                        newPoly.insertTerm(newTerm);
                        
                        // save the tokens
                        tokenList.add( new Operand(newPoly) );
                        tokenList.add( new Operator(c) );
                        
                        // Reset variables
                        newPoly = new Polynomial();
                        newExponent = "0";
                        newCoefficient = "0";
                    }
                    // if given a number, save it to the degree and keep state
                    else if (Character.isDigit(c))
                        newExponent += c;
                        
                    // anything else is error (ignore whitespace )
                    else if (c != ' ')
                        curState = State.ERR;
                    
                    break;
                    
                ////////////////////////////////////////////////////////////
                // waiting for an operator after a ')'...
                ////////////////////////////////////////////////////////////
                case WONLYOP:
                    if (isOperator(c)) {
                        lastOp = c;
                        
                        // add the operator token
                        tokenList.add( new Operator(c) );
                    
                        // if a closed paren, don't go to next state
                        if (c != ')')
                            curState = State.WTERM;
                    }
                    // anything else is error (ignore whitespace)
                    else if (c != ' ')
                        curState = State.ERR;
                    
                    break;
                    
                    
                    
                    
                    
                    
                default:
                    System.out.println("ERROR: non-valid state reached");
            }
        }
        
        // if we ended in a valid state
            if (curState.isAcceptState()) {
                // if there's still a pending polynomial
                if (newCoefficient != "0") {
                    // if given x but no exponent, assume it as 1
                    if (curState == State.WEXPO && newExponent == "0")
                        newExponent = "1";
                        
                    // put in the last term that wasn't saved by the
                    // finite state machine
                    newTerm = new Monomial(Double.parseDouble(newCoefficient),
                                           'x',
                                           Integer.parseInt(newExponent));
                            
                    newPoly.insertTerm(newTerm);
                    
                    tokenList.add( new Operand(newPoly) );
                }
                
                
                return tokenList;
            }
            
            // return null if invalid
            else return null;
        
    }
    
    /** mainline logic
     * 
     * @param args an array of strings
     */
    public static void main(String[] args) {
        // Make a new poly calculator
        PCalculator polyCalc = new PCalculator();
        // Prompt the user
        polyCalc.promptMenu();
    }
}

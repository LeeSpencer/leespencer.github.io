/**
 * Class for operators
 *
 * @author Spencer Lee
 * @version 1.0
 */

public class Operator extends AToken {

    /** the character of the operator */
    private final char opChar;
    
    /** the priority of the operator */
    private final int priority;
    
    /** Constructor for an operator
     * 
     * @param opChar the character representing the operator
     * @throws IllegalArgumentException if the operator is not +, -, *, /, (, or )
     */
    Operator(char opChar) throws IllegalArgumentException {
        if (opChar == '+' || opChar == '-')
            priority = 1;
                
        else if (opChar == '*' || opChar == '/')
            priority = 2;
            
        else if (opChar == '(' || opChar == ')')
            priority = -1;
                
        else throw new IllegalArgumentException("Operator must be " +
                                                "+, -, *, /, (, or )");
        
        this.opChar = opChar;
    }
    
    //methods
    
    public boolean isOpenParen() {
        return opChar == '(';
    }
    
    public boolean isCloseParen() {
        return opChar == ')';
    }
    
    public boolean isOperator() {
        return true;
    }
    
    public int getPriority() {
        return priority;
    }
    
    public Operand operate(AToken op1, AToken op2) throws IllegalArgumentException {
        Polynomial a = op1.getPoly();
        Polynomial b = op2.getPoly();
        
        // Don't operate if either operand is null
        if (a == null || b == null) {
            throw new IllegalArgumentException("ERROR: Operator.operate received null polynomials.");
        }
        
        // Check the character for the correct operation
        switch (opChar) {
            case '+':
                return new Operand( a.plus(b) );
            
            case '-':
                return new Operand( a.minus(b) );
            
            case '*':
                return new Operand( a.times(b) );
            
            case '/':
                return new Operand( a.divideBy(b) );
            
            default:
                System.out.println("ERROR: Operand.operate() received " +
                                   "unexpected operator");
                return null;
        }
    }
}

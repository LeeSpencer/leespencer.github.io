/**
 * Class for operands
 *
 * @author Spencer Lee
 * @version 1.0
 */

public class Operand extends AToken {

    /** the underlying polynomial */
    private final Polynomial poly;
    
    /** Constructor for an operand token
     * 
     * @param poly the underlying polynomial of the token
     */
    Operand(Polynomial poly) {
        this.poly = poly;
    }
    
    //methods
    
    public boolean isOperand() {
        return true;
    }
    
    public Polynomial getPoly() {
        return poly;
    }
}

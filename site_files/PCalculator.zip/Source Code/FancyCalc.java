/**
 * Class for the calculator with GUI
 *
 * @author Spencer Lee
 * @version 1.0
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.*;

public class FancyCalc {
    private PCalculator polyCalc;
    
    private JFrame window;
    private JFrame fileResults;
    private JPanel container;
    private JLabel lastExp;
    private GridBagConstraints gbc;
    private JTextField expressionField;
    
    private JButton       openFile;
    private JButton one,   two,   three,
                    four,  five,  six, 
                    seven, eight, nine, 
                           zero;
    private JButton plus, minus, times, divide, equals, 
                    openParen, closeParen, dot, carat, enter;
   
    private static final String ENTER = "en";
    private static final String OPEN_FILE = "of";
    
    private class ButtonHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
                final String ac = e.getActionCommand();
                String expression = FancyCalc.this.expressionField.getText();
                String result = "";
                
                switch (ac) {
                    case ENTER:
                        // evaluate
                        result = polyCalc.parseExpression(expression, true);
                        FancyCalc.this.expressionField.setText(result);
                        FancyCalc.this.lastExp.setText(result);
                        break;
                    case OPEN_FILE:
                        final JFileChooser fc;
                        FileNameExtensionFilter filter;
                        int returnVal;
                        
                        // read file, display in new window
                        fc = new JFileChooser();
                        filter = new FileNameExtensionFilter("Text files", "txt");
                        fc.setFileFilter(filter);

                        returnVal = fc.showOpenDialog(window);

                        if (returnVal == JFileChooser.APPROVE_OPTION) {
                            File file = fc.getSelectedFile();
                            
                            // buffered reading
                            try {
                                BufferedReader br = new BufferedReader(new FileReader(file));

                                // read the first line, check if it is null, if not, keep reading
                                for (String line = br.readLine(); line != null; line = br.readLine()) {
                                    // Evaluate the line
                                    result += polyCalc.parseExpression(line, true);
                                }

                                // close the reader
                                br.close();
                                
                                // open new window
                                fileResults = new JFrame("File Results");
                                fileResults.setSize(600, 480);
                                fileResults.setLocationRelativeTo(null);
                                fileResults.setVisible(true);
                                fileResults.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                            }
                            catch (IOException ex) {
                                System.err.println(e);
                            }
                        }
                        break;
                        
                    default:
                        expressionField.setText(expressionField.getText() + ac);
            }
        }
    }
    // start with interactive mode, opening file will produce new window
    
    FancyCalc(PCalculator polyCalc) {
        this.polyCalc = polyCalc;
        
        window = new JFrame("PCalculator");
        window.setSize(600, 480);
        window.setLocationRelativeTo(null);
        window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        container = new JPanel(new GridBagLayout());
        window.setContentPane(container);
        
        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.gridwidth = 4;
        
        openFile = new JButton("Open File");
        openFile.setActionCommand(OPEN_FILE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        container.add(openFile, gbc);

        expressionField = new JTextField();
        expressionField.setHorizontalAlignment(JTextField.RIGHT);
        gbc.gridx = 0;
        gbc.gridy = 1;
        container.add(expressionField, gbc);
        
        lastExp = new JLabel();
        lastExp.setHorizontalAlignment(SwingConstants.RIGHT);
        gbc.gridx = 0;
        gbc.gridy = 2;
        container.add(lastExp, gbc);
        
        gbc.gridwidth = 1;
        
        one = new JButton("1");
        gbc.gridx = 0;
        gbc.gridy = 3;
        container.add(one, gbc);
        
        two = new JButton("2");
        gbc.gridx = 1;
        gbc.gridy = 3;
        container.add(two, gbc);
        
        three = new JButton("3");
        gbc.gridx = 2;
        gbc.gridy = 3;
        container.add(three, gbc);
        
        four = new JButton("4");
        gbc.gridx = 0;
        gbc.gridy = 4;
        container.add(four, gbc);
        
        five = new JButton("5");
        gbc.gridx = 1;
        gbc.gridy = 4;
        container.add(five, gbc);
        
        six = new JButton("6");
        gbc.gridx = 2;
        gbc.gridy = 4;
        container.add(six, gbc);
        
        seven = new JButton("7");
        gbc.gridx = 0;
        gbc.gridy = 5;
        container.add(seven, gbc);
        
        eight = new JButton("8");
        gbc.gridx = 1;
        gbc.gridy = 5;
        container.add(eight, gbc);
        
        nine = new JButton("9");
        gbc.gridx = 2;
        gbc.gridy = 5;
        container.add(nine, gbc);
        
        zero = new JButton("0");
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 3;
        container.add(zero, gbc);
        
        enter = new JButton("Enter");
        enter.setActionCommand(ENTER);
        gbc.gridx = 3;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.gridheight = 4;
        container.add(enter, gbc);
        
        ActionListener al = new ButtonHandler();
        
        one.addActionListener(al);
        two.addActionListener(al);
        three.addActionListener(al);
        four.addActionListener(al);
        five.addActionListener(al);
        six.addActionListener(al);
        seven.addActionListener(al);
        eight.addActionListener(al);
        nine.addActionListener(al);
        zero.addActionListener(al);
        enter.addActionListener(al);
        openFile.addActionListener(al);
        
        
        window.setVisible(true);
        window.toFront();
    }
}

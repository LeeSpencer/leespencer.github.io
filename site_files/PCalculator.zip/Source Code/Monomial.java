/**
 * Class representation of a monomial
 *
 * @author Spencer Lee
 * @version 1.0
 */

import java.util.*;

public class Monomial implements Comparable<Monomial> {
    /** the coefficient */
    private double coefficient;
    /** the exponent */
    private int exponent;
    /** the variable character */
    private char variable;
    
    //constructor
    
    /** Constructor for a monomial
     * 
     * @param coefficient the coefficient of the monomial
     * @param variable the alphabetic variable of the monomial
     * @param exponent the exponent of the monomial
     */
    Monomial(double coefficient, char variable, int exponent) {
        this.coefficient = coefficient;
        this.exponent = exponent;
        this.variable = variable;
    }
    
    /** Overriding the compareTo method based on exponents in descending order
     * 
     * @param b the second monomial to compare with
     * @return -1 if greater, 0 if equal, 1 if less
     */
    public int compareTo(Monomial b) {
        return b.getExpt() - getExpt();
    }
    
    /** Getter for coefficients
     * 
     * @return the coefficient of the monomial
     */
    public double getCoeff() {
        return coefficient;
    }
    
    /** Getter for exponents
     * 
     * @return the exponent of the monomial
     */
    public int getExpt() {
        return exponent;
    }
    
    /** Getter for variables
     * 
     * @return the variable of the monomial
     */
    public char getVar() {
        return variable;
    }
    
    /** Clones the monomial
     * 
     * @return a copy of the monomial
     */
    public Monomial clone() {
        return new Monomial(coefficient, variable, exponent);
    }
    
    /** Adds two monomials together
     * 
     * @return a monomial, the result of adding b to this
     * @param b another monomial to be added
     */
    public Monomial plus(Monomial b) {
        double newCoeff = coefficient + b.getCoeff();
        
        if ( variable != b.getVar() || exponent != b.getExpt() ) {
            System.out.println("ERROR: monomial plus recieved bad variables");
            return null;
        }
        
        return new Monomial(newCoeff, variable, exponent);
    }
    
    /** Subtracts two monomials
     * 
     * @return a monomial, the result of subtracting b from this
     * @param b another monomial to be subtracted
     */
    public Monomial minus(Monomial b) {
        double newCoeff = coefficient - b.getCoeff();
        
        if ( variable != b.getVar() || exponent != b.getExpt() ) {
            System.out.println("ERROR: monomial minus recieved bad variables");
            return null;
        }
        
        return new Monomial(newCoeff, variable, exponent);
    }
    
    /** Multiplies two monomials
     * 
     * @return a monomial, the result of multiplying this with b
     * @param b another monomial to be multiplied
     */
    public Monomial times(Monomial b) {
        double newCoeff = coefficient * b.getCoeff();
        int newExpt;
        
        if ( variable != b.getVar() ) {
            System.out.println("ERROR: monomial times recieved bad variables");
            return null;
        }
        
        newExpt = exponent + b.getExpt();
        
        return new Monomial(newCoeff, variable, newExpt);
    }
    
    /** Divides two monomials
     * 
     * @return a monomial, the result of dividing this by b
     * @param b another monomial to divide by
     */
    public Monomial divideBy(Monomial b) {
        double newCoeff = coefficient / b.getCoeff();
        int newExpt;
        
        if ( variable != b.getVar() ) {
            System.out.println("ERROR: monomial divide recieved bad variables");
            return null;
        }
        
        newExpt = exponent - b.getExpt();
        
        return new Monomial(newCoeff, variable, newExpt);
    }
}

/**
 * Enumeration of states when parsing an expression
 *
 * @author Spencer Lee
 * @version 1.0
 */

public enum State {

    
    /** Waiting for a term */
    WTERM(false),
    /** Waiting for an operator after a polynomial */
    WPLYOP(true), 
    /** Waiting for a number after a decimal */
    WDNUM(false),
    /** Waiting for a degree after ^ */
    WDEGR(false), 
    /** Error state */
    ERR(false), 
    /** Waiting for an operator (only an operator and nothing else */
    WONLYOP(true),
    /** Waiting for a variable after a number */
    WVAR(true), 
    /** Waiting for any sign of an exponent (^) */
    WEXPO(true), 
    /** Waiting for an operator after the degree is given */
    WOPER(true);

    /** Determines whether the state is valid or not */
    private final boolean acceptState; 

    /** Constructor for a State
     * 
     * @param acceptState true or false if the state is valid
     */
    State(boolean acceptState){
      this.acceptState = acceptState;
    }

    /** Getter to check if the state is valid
     * 
     * @return true if the state is valid
     */
    public boolean isAcceptState(){
        return acceptState;
    }
}

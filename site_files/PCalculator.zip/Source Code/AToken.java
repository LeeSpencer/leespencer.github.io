/**
 * Abstract class for arithmetic tokens
 *
 * @author Spencer Lee
 * @version 1.0
 */

public class AToken {
    
    //methods
    
    /** Getter to check if the token is an operand
     * 
     * @return true if the token is an operand
     */
    public boolean isOperand() {
        return false;
    }
    
    /** Getter to check if the token is an operator
     * 
     * @return true if the token is an operator
     */
    public boolean isOperator() {
        return false;
    }
    
    /** Getter to check if the token is an open parenthesis
     * 
     * @return true if the token is an open parenthesis
     */
    public boolean isOpenParen() {
        return false;
    }
    
    /** Getter to check if the token is a closed parenthesis
     * 
     * @return true if the token is a closed parenthesis
     */
    public boolean isCloseParen() {
        return false;
    }
    
    /** Getter for the token's priority
     * 
     * @return the token's priority
     */
    public int getPriority() {
        return -2;
    }
    
    /** Operates on two operands depending on the operator
     * 
     * @return the operation
     * @throws IllegalArgumentException if either of the operands are null
     */
    public Operand operate(AToken op1, AToken op2) {
        return null;
    }
    
    /** Getter for the token's polynomial value
     * 
     * @return the token's polynomial value
     */
    public Polynomial getPoly() {
        return null;
    }
}
